import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class button implements ActionListener {

    // Global Declarations
    static String button;
    static String book;
    static JFrame f;
    static JFrame y;
    static JButton b1;
    static JButton b2;
    static JButton b3;
    static JButton b4;

    static String fromstring;
    static String tostring;
    static String classstring;
    static String pwdstring;
    int i = 0;

    // Main function
    public static void main(String args[]) {
        // Frame fixing
        JFrame checkframe = new JFrame("BOOK STORE");

        b1 = new JButton("Magic Shop");
        b1.setBounds(75, 250, 150, 30);
        b2 = new JButton("A million Thoughts");
        b2.setBounds(250, 250, 150, 30);
        b3 = new JButton("Believe in Yourself");
        b3.setBounds(425, 250, 150, 30);
        b4 = new JButton("Life of Pie");
        b4.setBounds(600, 250, 150, 30);

        // Event handling using button
        App obj = new App();
        b1.addActionListener(obj);
        b2.addActionListener(obj);
        b3.addActionListener(obj);
        b4.addActionListener(obj);

        
        checkframe.add(b1);
        checkframe.add(b2);
        checkframe.add(b3);
        checkframe.add(b4);
        checkframe.setLayout(null);
        checkframe.setSize(800, 700);
        checkframe.setLocationRelativeTo(null);
        checkframe.setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
       
        
    }
}
